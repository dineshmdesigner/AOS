<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:padding="20dp"
    android:background="#FFFFFF">

    <!-- Button to open DatePicker -->
    <Button
        android:id="@+id/btnDate"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Select Date"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="100dp" />

    <!-- TextView to display selected date -->
    <TextView
        android:id="@+id/txtDate"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Selected Date: "
        android:textSize="18sp"
        android:textStyle="bold"
        android:layout_below="@id/btnDate"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="30dp" />

</RelativeLayout>


java....


package com.example.datepickerapp;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Button btnDate;
    TextView txtDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnDate = findViewById(R.id.btnDate);
        txtDate = findViewById(R.id.txtDate);

        btnDate.setOnClickListener(v -> {

            // Get current date
            Calendar c = Calendar.getInstance();
            int year = c.get(Calendar.YEAR);
            int month = c.get(Calendar.MONTH);
            int day = c.get(Calendar.DAY_OF_MONTH);

            // Open DatePicker Dialog
            DatePickerDialog datePickerDialog = new DatePickerDialog(
                    MainActivity.this,
                    (view, selectedYear, selectedMonth, selectedDay) -> {

                        // Month starts from 0, so add 1
                        selectedMonth = selectedMonth + 1;

                        // Display selected date
                        txtDate.setText("Selected Date: " +
                                selectedDay + "/" + selectedMonth + "/" + selectedYear);

                    }, year, month, day);

            datePickerDialog.show();
        });
    }
}