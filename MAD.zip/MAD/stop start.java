<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:padding="20dp"
    android:background="#FFFFFF">

    <!-- Counter Display -->
    <TextView
        android:id="@+id/txtCounter"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="0"
        android:textSize="32sp"
        android:textStyle="bold"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="100dp" />

    <!-- START Button -->
    <Button
        android:id="@+id/btnStart"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="START"
        android:layout_below="@id/txtCounter"
        android:layout_marginTop="40dp"
        android:layout_alignParentStart="true" />

    <!-- STOP Button -->
    <Button
        android:id="@+id/btnStop"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="STOP"
        android:layout_below="@id/txtCounter"
        android:layout_marginTop="40dp"
        android:layout_alignParentEnd="true" />

</RelativeLayout>

java....

package com.example.counterapp;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    TextView txtCounter;
    Button btnStart, btnStop;

    int count = 0;
    Handler handler = new Handler();
    Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtCounter = findViewById(R.id.txtCounter);
        btnStart = findViewById(R.id.btnStart);
        btnStop = findViewById(R.id.btnStop);

        runnable = new Runnable() {
            @Override
            public void run() {
                count++;
                txtCounter.setText(String.valueOf(count));

                // repeat every 1 second
                handler.postDelayed(this, 1000);
            }
        };

        btnStart.setOnClickListener(v -> {
            handler.post(runnable);
        });

        btnStop.setOnClickListener(v -> {
            handler.removeCallbacks(runnable);
        });
    }
}