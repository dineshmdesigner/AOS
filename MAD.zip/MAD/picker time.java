<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:padding="20dp"
    android:background="#FFFFFF">

    <!-- Button to open Time Picker -->
    <Button
        android:id="@+id/btnTime"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Select Time"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="100dp" />

    <!-- TextView to display selected time -->
    <TextView
        android:id="@+id/txtTime"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Selected Time: "
        android:textSize="18sp"
        android:textStyle="bold"
        android:layout_below="@id/btnTime"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="30dp" />

</RelativeLayout>

java....

package com.example.timepickerapp;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.util.Calendar;

public class MainActivity extends AppCompatActivity {

    Button btnTime;
    TextView txtTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnTime = findViewById(R.id.btnTime);
        txtTime = findViewById(R.id.txtTime);

        btnTime.setOnClickListener(v -> {

            // Get current time
            Calendar c = Calendar.getInstance();
            int hour = c.get(Calendar.HOUR_OF_DAY);
            int minute = c.get(Calendar.MINUTE);

            // Open TimePicker Dialog
            TimePickerDialog timePickerDialog = new TimePickerDialog(
                    MainActivity.this,
                    (view, selectedHour, selectedMinute) -> {

                        // Display selected time
                        txtTime.setText("Selected Time: " +
                                selectedHour + ":" + selectedMinute);

                    }, hour, minute, true);

            timePickerDialog.show();
        });
    }
}