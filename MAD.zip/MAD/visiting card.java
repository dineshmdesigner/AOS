<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:padding="20dp"
    android:background="#FFFFFF">

    <!-- Logo in Right Corner -->
    <ImageView
        android:id="@+id/logo"
        android:layout_width="60dp"
        android:layout_height="60dp"
        android:layout_alignParentTop="true"
        android:layout_alignParentEnd="true"
        android:src="@drawable/ic_launcher_foreground" />

    <!-- Name in Center -->
    <TextView
        android:id="@+id/name"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="DINESH DESIGNER"
        android:textSize="24sp"
        android:textStyle="bold"
        android:textAllCaps="true"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="80dp" />

    <!-- Job Title -->
    <TextView
        android:id="@+id/job"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Graphic Designer"
        android:textSize="18sp"
        android:layout_below="@id/name"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="10dp" />

    <!-- Phone Number -->
    <TextView
        android:id="@+id/phone"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Phone: 9876543210"
        android:textSize="16sp"
        android:layout_below="@id/job"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="10dp" />

    <!-- Address -->
    <TextView
        android:id="@+id/address"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Chengalpattu, Tamil Nadu"
        android:textSize="16sp"
        android:layout_below="@id/phone"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="10dp" />

</RelativeLayout>


java...

package com.example.visitingcard;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}