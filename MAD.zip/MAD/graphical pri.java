Step 1: Create Custom View (MyView.java)
package com.example.graphicsapp;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class MyView extends View {

    Paint paint;

    public MyView(Context context) {
        super(context);
        paint = new Paint();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        // Background color
        canvas.drawColor(Color.WHITE);

        // Draw Line
        paint.setColor(Color.RED);
        paint.setStrokeWidth(5);
        canvas.drawLine(100, 100, 500, 100, paint);

        // Draw Rectangle
        paint.setColor(Color.BLUE);
        paint.setStyle(Paint.Style.STROKE);
        canvas.drawRect(100, 200, 500, 400, paint);

        // Draw Circle
        paint.setColor(Color.GREEN);
        paint.setStyle(Paint.Style.FILL);
        canvas.drawCircle(300, 600, 100, paint);
    }
}


java.....


package com.example.graphicsapp;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set custom view as screen
        MyView myView = new MyView(this);
        setContentView(myView);
    }
}