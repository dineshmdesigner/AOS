<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:id="@+id/mainLayout"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#FFFFFF">

</RelativeLayout>


....res → menu → right click → New → Menu Resource File
Name it: menu_main.xml......

<?xml version="1.0" encoding="utf-8"?>
<menu xmlns:android="http://schemas.android.com/apk/res/android">

    <item android:id="@+id/red"
        android:title="Red" />

    <item android:id="@+id/green"
        android:title="Green" />

    <item android:id="@+id/blue"
        android:title="Blue" />

    <item android:id="@+id/yellow"
        android:title="Yellow" />

</menu>

java....


package com.example.colorchange;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.RelativeLayout;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    RelativeLayout layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        layout = findViewById(R.id.mainLayout);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        if (item.getItemId() == R.id.red) {
            layout.setBackgroundColor(Color.RED);
        } else if (item.getItemId() == R.id.green) {
            layout.setBackgroundColor(Color.GREEN);
        } else if (item.getItemId() == R.id.blue) {
            layout.setBackgroundColor(Color.BLUE);
        } else if (item.getItemId() == R.id.yellow) {
            layout.setBackgroundColor(Color.YELLOW);
        }

        return true;
    }
}