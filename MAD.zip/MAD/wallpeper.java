Permission Required (AndroidManifest.xml)
<uses-permission android:name="android.permission.SET_WALLPAPER"/>
✅ Step 1: XML Layout (activity_main.xml)
<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:background="#FFFFFF"
    android:gravity="center">

    <Button
        android:id="@+id/btnStart"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Start Changing Wallpaper"
        android:layout_centerInParent="true" />

</RelativeLayout>


java...

package com.example.wallpaperapp;

import android.app.WallpaperManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    Button btnStart;
    Handler handler = new Handler();

    int[] images = {
            R.drawable.img1,
            R.drawable.img2,
            R.drawable.img3
    };

    Runnable runnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnStart = findViewById(R.id.btnStart);

        btnStart.setOnClickListener(v -> {

            runnable = new Runnable() {
                @Override
                public void run() {
                    try {
                        // Pick random image
                        int randomIndex = new Random().nextInt(images.length);

                        Bitmap bitmap = BitmapFactory.decodeResource(
                                getResources(), images[randomIndex]);

                        // Set wallpaper
                        WallpaperManager manager = WallpaperManager.getInstance(MainActivity.this);
                        manager.setBitmap(bitmap);

                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                    // Repeat every 30 seconds
                    handler.postDelayed(this, 30000);
                }
            };

            handler.post(runnable);
        });
    }
}