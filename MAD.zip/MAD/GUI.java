<?xml version="1.0" encoding="utf-8"?>
<RelativeLayout xmlns:android="http://schemas.android.com/apk/res/android"
    android:layout_width="match_parent"
    android:layout_height="match_parent"
    android:padding="20dp"
    android:background="#E3F2FD">

    <!-- Title -->
    <TextView
        android:id="@+id/title"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="User Form"
        android:textSize="26sp"
        android:textStyle="bold"
        android:textColor="#0D47A1"
        android:layout_centerHorizontal="true" />

    <!-- Name Input -->
    <EditText
        android:id="@+id/name"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="Enter Name"
        android:textColor="#000000"
        android:textSize="18sp"
        android:layout_below="@id/title"
        android:layout_marginTop="30dp" />

    <!-- Email Input -->
    <EditText
        android:id="@+id/email"
        android:layout_width="match_parent"
        android:layout_height="wrap_content"
        android:hint="Enter Email"
        android:textColor="#000000"
        android:textSize="18sp"
        android:layout_below="@id/name"
        android:layout_marginTop="20dp" />

    <!-- Submit Button -->
    <Button
        android:id="@+id/submitBtn"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Submit"
        android:textSize="18sp"
        android:textColor="#FFFFFF"
        android:background="#1976D2"
        android:layout_below="@id/email"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="30dp" />

    <!-- Output Text -->
    <TextView
        android:id="@+id/output"
        android:layout_width="wrap_content"
        android:layout_height="wrap_content"
        android:text="Result will appear here"
        android:textSize="18sp"
        android:textColor="#1B5E20"
        android:layout_below="@id/submitBtn"
        android:layout_centerHorizontal="true"
        android:layout_marginTop="30dp" />

</RelativeLayout>


java....

package com.example.guicomponents;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    EditText name, email;
    Button submitBtn;
    TextView output;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        name = findViewById(R.id.name);
        email = findViewById(R.id.email);
        submitBtn = findViewById(R.id.submitBtn);
        output = findViewById(R.id.output);

        submitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String n = name.getText().toString();
                String e = email.getText().toString();

                output.setText("Name: " + n + "\nEmail: " + e);
            }
        });
    }
}