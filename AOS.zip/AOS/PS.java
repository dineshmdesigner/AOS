import java.util.*;

class Priority_NonPreemptive {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of processes: ");
        int n = sc.nextInt();

        int[] at = new int[n];
        int[] bt = new int[n];
        int[] pr = new int[n]; // Priority
        int[] ct = new int[n];
        int[] tat = new int[n];
        int[] wt = new int[n];
        boolean[] completed = new boolean[n];

        for (int i = 0; i < n; i++) {
            System.out.print("Enter Arrival Time for P" + (i+1) + ": ");
            at[i] = sc.nextInt();

            System.out.print("Enter Burst Time for P" + (i+1) + ": ");
            bt[i] = sc.nextInt();

            System.out.print("Enter Priority for P" + (i+1) + ": ");
            pr[i] = sc.nextInt();
        }

        int time = 0, completedCount = 0;

        while (completedCount < n) {
            int idx = -1;
            int highestPriority = Integer.MAX_VALUE;

            for (int i = 0; i < n; i++) {
                if (!completed[i] && at[i] <= time && pr[i] < highestPriority) {
                    highestPriority = pr[i];
                    idx = i;
                }
            }

            if (idx == -1) {
                time++;
            } else {
                time += bt[idx];
                ct[idx] = time;
                completed[idx] = true;
                completedCount++;
            }
        }

        double totalWT = 0, totalTAT = 0;

        for (int i = 0; i < n; i++) {
            tat[i] = ct[i] - at[i];
            wt[i] = tat[i] - bt[i];

            totalWT += wt[i];
            totalTAT += tat[i];
        }

        System.out.println("\nP\tAT\tBT\tPR\tCT\tTAT\tWT");
        for (int i = 0; i < n; i++) {
            System.out.println("P" + (i+1) + "\t" + at[i] + "\t" + bt[i] + "\t" + pr[i] + "\t" + ct[i] + "\t" + tat[i] + "\t" + wt[i]);
        }

        System.out.println("\nAverage Waiting Time: " + (totalWT / n));
        System.out.println("Average Turnaround Time: " + (totalTAT / n));

        sc.close();
    }
}