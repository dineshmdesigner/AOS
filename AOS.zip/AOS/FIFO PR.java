import java.util.*;

public class FIFOPageReplacement {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of frames: ");
        int frames = sc.nextInt();
        sc.nextLine();

        System.out.print("Enter page reference string: ");
        String[] input = sc.nextLine().split(" ");

        List<Integer> frame = new ArrayList<>();
        int fault = 0;

        for (String s : input) {
            int page = Integer.parseInt(s);

            if (!frame.contains(page)) {
                if (frame.size() < frames) {
                    frame.add(page);
                } else {
                    frame.remove(0);
                    frame.add(page);
                }
                fault++;
                System.out.println(page + " -> " + frame + " Page Fault");
            } else {
                System.out.println(page + " -> " + frame + " Page Hit");
            }
        }

        System.out.println("Total Page Faults = " + fault);

        sc.close();
    }
}