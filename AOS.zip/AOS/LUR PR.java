import java.util.*;

public class LRU {
    public static void main(String[] args) {
        int[] pages = {1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5};
        int frames = 3;
        lruPageReplacement(pages, frames);
    }

    public static void lruPageReplacement(int[] pages, int frames) {
        List<Integer> memory = new ArrayList<>();
        Map<Integer, Integer> recentUse = new HashMap<>();

        int time = 0;
        int pageFaults = 0;

        for (int page : pages) {
            time++;

            if (!memory.contains(page)) {
                if (memory.size() == frames) {
                    int lruPage = memory.get(0);
                    int minTime = recentUse.get(lruPage);

                    for (int p : memory) {
                        if (recentUse.get(p) < minTime) {
                            minTime = recentUse.get(p);
                            lruPage = p;
                        }
                    }

                    memory.remove((Integer) lruPage);
                }

                memory.add(page);
                pageFaults++; 

                System.out.println(page + " -> " + memory + " Page Fault");
            } else {
                System.out.println(page + " -> " + memory + " Page Hit");
            }

            recentUse.put(page, time);
        }

        System.out.println("Total Page Faults = " + pageFaults);
    }
}