import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class DeadlockExample {

    static Lock lock1 = new ReentrantLock();
    static Lock lock2 = new ReentrantLock();

    public static void main(String[] args) {

        Thread t1 = new Thread(() -> {
            System.out.println("Thread1 trying to acquire Lock1");
            lock1.lock();
            System.out.println("Thread1 acquired Lock1");

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {}

            System.out.println("Thread1 trying to acquire Lock2");
            lock2.lock();
            System.out.println("Thread1 acquired Lock2");
        });

        Thread t2 = new Thread(() -> {
            System.out.println("Thread2 trying to acquire Lock2");
            lock2.lock();
            System.out.println("Thread2 acquired Lock2");

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {}

            System.out.println("Thread2 trying to acquire Lock1");
            lock1.lock();
            System.out.println("Thread2 acquired Lock1");
        });

        t1.start();
        t2.start();
    }
}