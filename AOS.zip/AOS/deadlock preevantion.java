import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class NoDeadlockExample {

    static Lock lock1 = new ReentrantLock();
    static Lock lock2 = new ReentrantLock();

    public static void process(String name) {
        System.out.println(name + " trying to acquire Lock1");
        lock1.lock();

        try {
            System.out.println(name + " acquired Lock1");

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {}

            System.out.println(name + " trying to acquire Lock2");
            lock2.lock();

            try {
                System.out.println(name + " acquired Lock2");
                System.out.println(name + " executing critical section");
            } finally {
                lock2.unlock();
            }

        } finally {
            lock1.unlock();
        }
    }

    public static void main(String[] args) throws InterruptedException {
        Thread t1 = new Thread(() -> process("Thread1"));
        Thread t2 = new Thread(() -> process("Thread2"));

        t1.start();
        t2.start();

        t1.join();
        t2.join();

        System.out.println("Execution completed without deadlock");
    }
}