import java.util.*;

class RoundRobin {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of processes: ");
        int n = sc.nextInt();

        int[] at = new int[n];
        int[] bt = new int[n];
        int[] rt = new int[n];
        int[] ct = new int[n];
        int[] tat = new int[n];
        int[] wt = new int[n];

        for (int i = 0; i < n; i++) {
            System.out.print("Enter Arrival Time for P" + (i+1) + ": ");
            at[i] = sc.nextInt();

            System.out.print("Enter Burst Time for P" + (i+1) + ": ");
            bt[i] = sc.nextInt();

            rt[i] = bt[i];
        }

        System.out.print("Enter Time Quantum: ");
        int tq = sc.nextInt();

        int completed = 0, time = 0;

        while (completed < n) {
            boolean done = true;

            for (int i = 0; i < n; i++) {
                if (rt[i] > 0 && at[i] <= time) {
                    done = false;

                    if (rt[i] > tq) {
                        time += tq;
                        rt[i] -= tq;
                    } else {
                        time += rt[i];
                        ct[i] = time;
                        rt[i] = 0;
                        completed++;
                    }
                }
            }

            if (done) {
                time++;
            }
        }

        double totalWT = 0, totalTAT = 0;

        for (int i = 0; i < n; i++) {
            tat[i] = ct[i] - at[i];
            wt[i] = tat[i] - bt[i];

            totalWT += wt[i];
            totalTAT += tat[i];
        }

        System.out.println("\nP\tAT\tBT\tCT\tTAT\tWT");
        for (int i = 0; i < n; i++) {
            System.out.println("P" + (i+1) + "\t" + at[i] + "\t" + bt[i] + "\t" + ct[i] + "\t" + tat[i] + "\t" + wt[i]);
        }

        System.out.println("\nAverage Waiting Time: " + (totalWT / n));
        System.out.println("Average Turnaround Time: " + (totalTAT / n));

        sc.close();
    }
}