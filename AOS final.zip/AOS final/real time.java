import java.util.*;

public class EDFScheduling {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of tasks: ");
        int n = sc.nextInt();

        int[][] tasks = new int[n][3];

        for (int i = 0; i < n; i++) {
            System.out.print("Execution Time for Task " + (i + 1) + ": ");
            tasks[i][1] = sc.nextInt();

            System.out.print("Deadline for Task " + (i + 1) + ": ");
            tasks[i][2] = sc.nextInt();

            tasks[i][0] = i + 1;
        }

        Arrays.sort(tasks, (a, b) -> a[2] - b[2]);

        int time = 0;

        System.out.println("\nTask Execution Order (EDF):");

        for (int i = 0; i < n; i++) {
            int tid = tasks[i][0];
            int et = tasks[i][1];
            int dl = tasks[i][2];

            time += et;

            String status;
            if (time <= dl)
                status = "Met Deadline";
            else
                status = "Missed Deadline";

            System.out.println("Task " + tid + 
                               " Completed at " + time + 
                               " - " + status);
        }

        sc.close();
    }
}