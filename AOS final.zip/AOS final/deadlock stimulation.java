import threading
import time

lock1 = threading.Lock()
lock2 = threading.Lock()

def thread1():
    print("Thread 1 trying to acquire lock1")
    lock1.acquire()
    print("Thread 1 acquired lock1")

    time.sleep(1)

    print("Thread 1 trying to acquire lock2")
    lock2.acquire()
    print("Thread 1 acquired lock2")

def thread2():
    print("Thread 2 trying to acquire lock2")
    lock2.acquire()
    print("Thread 2 acquired lock2")

    time.sleep(1)

    print("Thread 2 trying to acquire lock1")
    lock1.acquire()
    print("Thread 2 acquired lock1")

t1 = threading.Thread(target=thread1)
t2 = threading.Thread(target=thread2)

t1.start()
t2.start()