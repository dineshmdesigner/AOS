n = int(input("Enter number of processes: "))

bt = []
pr = []

for i in range(n):
    bt.append(int(input(f"Enter burst time for P{i+1}: ")))
    pr.append(int(input(f"Enter priority for P{i+1}: ")))

completed = [False] * n
wt = [0] * n
tat = [0] * n

time = 0

for _ in range(n):
    minp = -1
    
    for i in range(n):
        if not completed[i]:
            if minp == -1 or pr[i] < pr[minp]:
                minp = i

    wt[minp] = time
    time += bt[minp]
    tat[minp] = wt[minp] + bt[minp]
    completed[minp] = True

for i in range(n):
    print(f"Process P{i+1}: WT = {wt[i]}, TAT = {tat[i]}")