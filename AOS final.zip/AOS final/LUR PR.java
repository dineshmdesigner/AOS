frames = int(input("Enter number of frames: "))
pages = list(map(int, input("Enter page reference string: ").split()))

frame = []
fault = 0

for page in pages:
    if page not in frame:
        if len(frame) < frames:
            frame.append(page)
        else:
            frame.pop(0)   # remove least recently used
            frame.append(page)
        fault += 1
        print(page, "->", frame, "Page Fault")
    else:
        frame.remove(page)   # move page to most recent position
        frame.append(page)
        print(page, "->", frame, "Page Hit")

print("Total Page Faults =", fault)