import java.util.*;

public class DistributedScheduling {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of processors: ");
        int p = sc.nextInt();

        System.out.print("Enter number of processes: ");
        int n = sc.nextInt();

        int[] bt = new int[n];

        for (int i = 0; i < n; i++) {
            System.out.print("Burst Time for P" + (i + 1) + ": ");
            bt[i] = sc.nextInt();
        }

        int[] load = new int[p];
        int[] allocation = new int[n];

        for (int i = 0; i < n; i++) {
            int minp = 0;

            for (int j = 1; j < p; j++) {
                if (load[j] < load[minp]) {
                    minp = j;
                }
            }

            allocation[i] = minp;
            load[minp] += bt[i];
        }

        System.out.println("\nProcess Allocation:");
        for (int i = 0; i < n; i++) {
            System.out.println("Process " + (i + 1) + 
                               " -> Processor " + (allocation[i] + 1));
        }

        System.out.println("\nProcessor Loads: " + Arrays.toString(load));

        sc.close();
    }
}