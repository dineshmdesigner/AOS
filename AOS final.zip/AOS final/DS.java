p = int(input("Enter number of processors: "))
n = int(input("Enter number of processes: "))

bt = []
for i in range(n):
    bt.append(int(input(f"Enter burst time for P{i+1}: ")))

load = [0] * p

allocation = [0] * n

for i in range(n):
    minp = load.index(min(load)) 
    allocation[i] = minp
    load[minp] += bt[i]

for i in range(n):
    print(f"Process {i+1} assigned to Processor {allocation[i] + 1}")

print("Processor Loads:", load)