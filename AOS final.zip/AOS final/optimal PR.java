import java.util.*;

public class OptimalPageReplacement {

    static int findOptimal(int pages[], int frames[], int index) {
        int farthest = index;
        int replaceIndex = -1;

        for (int i = 0; i < frames.length; i++) {
            int j;

            for (j = index; j < pages.length; j++) {
                if (frames[i] == pages[j]) {
                    if (j > farthest) {
                        farthest = j;
                        replaceIndex = i;
                    }
                    break;
                }
            }

            if (j == pages.length) {
                return i;
            }
        }

        return (replaceIndex == -1) ? 0 : replaceIndex;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Enter number of frames: ");
        int f = sc.nextInt();

        System.out.print("Enter number of pages: ");
        int n = sc.nextInt();

        int pages[] = new int[n];

        System.out.println("Enter page reference string:");
        for (int i = 0; i < n; i++) {
            pages[i] = sc.nextInt();
        }

        int frames[] = new int[f];
        Arrays.fill(frames, -1);

        int pageFaults = 0;

        for (int i = 0; i < n; i++) {
            boolean hit = false;

            for (int j = 0; j < f; j++) {
                if (frames[j] == pages[i]) {
                    hit = true;
                    break;
                }
            }

            if (!hit) {
                int replaceIndex = -1;

                for (int j = 0; j < f; j++) {
                    if (frames[j] == -1) {
                        replaceIndex = j;
                        break;
                    }
                }

                if (replaceIndex == -1) {
                    replaceIndex = findOptimal(pages, frames, i + 1);
                }

                frames[replaceIndex] = pages[i];
                pageFaults++;

                System.out.print(pages[i] + " -> [");
                for (int j = 0; j < f; j++) {
                    if (frames[j] != -1)
                        System.out.print(frames[j] + (j < f - 1 ? ", " : ""));
                }
                System.out.println("] Page Fault");

            } else {
                System.out.print(pages[i] + " -> [");
                for (int j = 0; j < f; j++) {
                    if (frames[j] != -1)
                        System.out.print(frames[j] + (j < f - 1 ? ", " : ""));
                }
                System.out.println("] Page Hit");
            }
        }

        System.out.println("Total Page Faults = " + pageFaults);

        sc.close();
    }
}