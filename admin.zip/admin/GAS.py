#include <ESP8266WiFi.h>

#define smokeA0 A0
#define Alarm D2

int sensorThres = 500;

void setup() {
  pinMode(Alarm, OUTPUT);
  pinMode(smokeA0, INPUT);
  Serial.begin(9600);
}

void loop() {
  int Sensor = analogRead(smokeA0);
  Serial.println(Sensor);

  if (Sensor > sensorThres) {
    digitalWrite(Alarm, HIGH);
  } else {
    digitalWrite(Alarm, LOW);
  }

  delay(100);
}