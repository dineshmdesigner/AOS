#include "DHT.h"
#include <ESP8266WiFi.h>

#define DHTTYPE DHT11
const int DHTPin = D1;

DHT dht(DHTPin, DHTTYPE);

void setup() {
  Serial.begin(9600);
  delay(500);
  dht.begin();
  delay(500);
}

void loop() {
  int h = dht.readHumidity();
  float t = dht.readTemperature();

  String Temp = "Temperature: " + String(t) + " °C";
  String Humi = "Humidity: " + String(h) + " %";

  Serial.println(Temp);
  Serial.println(Humi);

  delay(1000);
}