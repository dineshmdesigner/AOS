void setup()
{
  pinMode(D0, INPUT);
  pinMode(D5, OUTPUT);
  Serial.begin(9600);
}

void loop()
{
  int sensorValue = digitalRead(D0);
  Serial.println(sensorValue);

  if(sensorValue < 1)
  {
    digitalWrite(D5, HIGH);
  }
  else
  {
    digitalWrite(D5, LOW);
  }
}