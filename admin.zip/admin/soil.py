#include <ESP8266WiFi.h>

const byte relayOnState = LOW;
const byte relayOffState = HIGH;

int SoilMoist = A0;   // Soil moisture sensor pin
int LED = D5;         // LED pin

void setup()
{
  pinMode(SoilMoist, INPUT);
  pinMode(LED, OUTPUT);
  Serial.begin(9600);
}

void loop()
{
  float moisture_percentage;

  moisture_percentage = 100.00 - ((analogRead(SoilMoist) / 1023.00) * 100.00);

  Serial.println(moisture_percentage);

  if (moisture_percentage <= 10)
  {
    digitalWrite(LED, relayOnState);
  }
  else
  {
    digitalWrite(LED, relayOffState);
  }
}